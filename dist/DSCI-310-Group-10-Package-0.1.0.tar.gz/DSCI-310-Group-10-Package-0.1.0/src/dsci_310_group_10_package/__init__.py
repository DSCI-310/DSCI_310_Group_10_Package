# read version from installed package
from importlib.metadata import version
__version__ = version("DSCI-310-Group-10-Package")